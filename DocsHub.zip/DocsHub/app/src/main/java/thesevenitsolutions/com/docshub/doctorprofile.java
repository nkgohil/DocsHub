package thesevenitsolutions.com.docshub;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.DialogFragment;
import ru.slybeaver.slycalendarview.SlyCalendarDialog;

import android.app.DatePickerDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;


import com.astritveliu.boom.Boom;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;


import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

public class doctorprofile extends AppCompatActivity implements SlyCalendarDialog.Callback {
    ImageButton bookappointment;
    ImageView docpersonalinfo,docworkingaddress,docprofile_back;
    RatingBar ratingBar;
    Context ctx=this;
    TextView textview;
    MaterialAlertDialogBuilder b1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        overridePendingTransition(R.anim.fade_in, R.anim.fade_out);
        setContentView(R.layout.activity_doctorprofile);
        allocatememory();
        setevent();



    }

    private void setevent() {
        docpersonalinfo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                LayoutInflater inflater = LayoutInflater.from(ctx);
                final View CustomDialog = inflater.inflate(R.layout.activity_doctorpersonalinfo,null);
                b1.setView(CustomDialog);
                b1.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {

                    }
                });
                b1.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        Toast.makeText(ctx,"Cancel button clicked",Toast.LENGTH_SHORT).show();
                    }
                });
                b1.create().show();



            }
        });
        ratingBar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String rating = "Rating is :" + ratingBar.getRating();
                Toast.makeText(doctorprofile.this, rating, Toast.LENGTH_LONG).show();
            }
        });

        findViewById(R.id.bookappointment).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new SlyCalendarDialog()

                        .setSingle(true)
                        .setFirstMonday(false)
                        .setCallback(doctorprofile.this)
                        .setHeaderColor(getColor(R.color.splashscreenbackground))
                        .show(getSupportFragmentManager(), "TAG_SLYCALENDAR");
            }
        });
    }

    private void allocatememory() {
        bookappointment=findViewById(R.id.bookappointment);
        docprofile_back=findViewById(R.id.docprofile_back);
        new Boom(bookappointment);
        new Boom(docprofile_back);
        docpersonalinfo=findViewById(R.id.docpersonalinfo);
        new Boom(docpersonalinfo);
        docworkingaddress=findViewById(R.id.docworkingaddress);
        new Boom(docworkingaddress);
       textview= findViewById(R.id.textview);
        ratingBar = findViewById(R.id.ratingbar1);
    }


    @Override
    public void onCancelled() {
    }

    @Override
    public void onDataSelected(Calendar firstDate, Calendar secondDate, int hours, int minutes) {
        if (firstDate != null) {
            if (secondDate == null) {
                firstDate.set(Calendar.HOUR_OF_DAY, hours);
                firstDate.set(Calendar.MINUTE, minutes);
                textview.setText(new SimpleDateFormat(getString(R.string.timeFormat), Locale.getDefault()).format(firstDate.getTime()));

            } else {
                Toast.makeText(
                        this,
                        getString(
                                R.string.period,
                                new SimpleDateFormat(getString(R.string.dateFormat), Locale.getDefault()).format(firstDate.getTime()),
                                new SimpleDateFormat(getString(R.string.timeFormat), Locale.getDefault()).format(secondDate.getTime())
                        ),
                        Toast.LENGTH_LONG

                ).show();
            }
        }
    }

}
